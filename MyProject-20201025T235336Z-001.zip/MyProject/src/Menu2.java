import edu.digipen.gameobject.GameObject;

/**
 * Created by arya.selvam on 8/8/2016.
 */
public class Menu2 extends GameObject
{
	public Menu2()
	{
		super("Menu", 340, 1000, "Menu2.png");

	}
}
