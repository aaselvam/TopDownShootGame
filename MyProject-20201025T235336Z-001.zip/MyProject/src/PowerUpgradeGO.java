import edu.digipen.gameobject.GameObject;

/**
 * Created by arya.selvam on 8/10/2016.
 */
public class PowerUpgradeGO extends GameObject
{
	public PowerUpgradeGO()
	{
		super("PowerUpgradePic", 1000, 1000, "upgrade.png");
	}
}
