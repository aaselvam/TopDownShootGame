import edu.digipen.gameobject.GameObject;
import edu.digipen.level.GameLevel;

/**
 * Created by arya.selvam on 8/11/2016.
 */
public class WIN extends GameLevel
{
	@Override public void create()
	{
		GameObject WINpic = new WINpic();

	}

	@Override public void initialize()
	{

	}

	@Override public void update(float v)
	{

	}

	@Override public void uninitialize()
	{

	}
}
