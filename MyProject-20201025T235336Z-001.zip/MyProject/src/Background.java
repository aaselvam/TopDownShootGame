import edu.digipen.gameobject.GameObject;

/**
 * Created by arya.selvam on 8/4/2016.
 */
public class Background extends GameObject
{
	public Background()
	{
		super("Background", 350, 1000, "Background.png");
	}
}
