import edu.digipen.gameobject.GameObject;

/**
 * Created by arya.selvam on 8/11/2016.
 */
public class CutscenePic2 extends GameObject
{
	public CutscenePic2()
	{
		super("Cutscene2",1000,1000,"Cutscene2.png");
	}
}
