import edu.digipen.gameobject.GameObject;

/**
 * Created by arya.selvam on 8/12/2016.
 */
public class StartPic extends GameObject
{
	public StartPic()
	{
		super("StartPic", 1000, 1000, "Beginning screen.png");
	}
}
