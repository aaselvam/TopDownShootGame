import edu.digipen.gameobject.GameObject;

/**
 * Created by arya.selvam on 8/9/2016.
 */
public class ReadyPic extends GameObject
{
	public ReadyPic()
	{
		super("Ready", 1000,1000, "ReadyPic.png");
	}
}
