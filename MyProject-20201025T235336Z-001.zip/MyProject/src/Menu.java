import edu.digipen.gameobject.GameObject;

/**
 * Created by arya.selvam on 8/5/2016.
 */
public class Menu extends GameObject
{
	public Menu()
	{
		super("Menu", 340, 1000, "Menu.png");

	}
}
