import edu.digipen.gameobject.GameObject;

/**
 * Created by arya.selvam on 8/8/2016.
 */
public class GameOverPic extends GameObject
{
	public GameOverPic()
	{
		super("GameOverPic", 1000,1000, "game over.png");
	}
}
