import edu.digipen.gameobject.GameObject;

/**
 * Created by arya.selvam on 8/11/2016.
 */
public class WINpic extends GameObject
{
	public WINpic()
	{
		super("WINpic", 1000, 1000, "WINpic.png");
	}
}
