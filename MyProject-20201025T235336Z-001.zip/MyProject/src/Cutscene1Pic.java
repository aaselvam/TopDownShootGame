import edu.digipen.gameobject.GameObject;

/**
 * Created by arya.selvam on 8/11/2016.
 */
public class Cutscene1Pic extends GameObject
{
	public Cutscene1Pic()
	{
		super("Cutscene1Pic",350,1000,"Cutscene1.png" );
	}
}
